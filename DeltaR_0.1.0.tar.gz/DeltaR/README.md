# DeltaR: DELTA Format Parser for R

## Overview

Provides an R interface to the tDelta C++ library for parsing    [DELTA]([DELTA](https://www.delta-intkey.com/)) (***DE**scription **L**anguage for **TA**xonomy*) format files. DELTA is a  widely-used standard for encoding taxonomic descriptions.

Supports loading character lists, item descriptions, and specifications, with efficient searching and matching of items based on character values.

## Installation

```r
# Install from CRAN (once submitted)
install.packages("DeltaR")

# Or install development version from GitHub
# remotes::install_github("yourusername/DeltaR")

# Or install locally
# install.packages("DeltaR_0.1.0.tar.gz", repos = NULL, type = "source")
```

### Getting Started